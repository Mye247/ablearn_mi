function homePageLoader() {}

export default homePageLoader;
