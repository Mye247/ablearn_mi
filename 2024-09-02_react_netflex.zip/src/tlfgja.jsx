/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
const { useEffect } = require("react");



useEffect(() => {
  const intervalId = setInterval(() => {}, 2000);

  return () => {
    // 언마운트 직전에 실행
    clearInterval(intervalId);
  };
}, []);




// list ui
function SomeComponent() {
  const names = ["신하은", "조은진", "박수혁"];
  return (
    <div>
      <h1>우리반 친구들 이름 목록</h1>
      <ul>
        {names.map((name) => (
          <li key={name}>{name}</li> // 키값으로는 배열에서 유일한 값을 넣어야한다
        ))}
      </ul>
    </div>
  );
}

export default SomeComponent;
