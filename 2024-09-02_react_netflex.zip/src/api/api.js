import axios from "axios";
//유지보수성 올리기

const baseURL = "https://api.themoviedb.org"; // 변하지 않는 확실한 주소 넣기
const accessToken =
  "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJkYjdiMTJjM2M2NjhiMjNjZThhNmNhMjFiYTE5M2JjYiIsIm5iZiI6MTcyNDgzMjQ5NC41NTE1NTMsInN1YiI6IjY1YTlkNjZjNTM0NjYxMDEzOGNkMTFhYiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.rRVZwTNunIYGQ1-wPudD_JX_4KKTVWUSXtLP5Y4ARqs";

const tmdbClient = axios.create({
  baseURL,
  headers: {
    Authorization: accessToken,
  },
});

export const getMoviesOnCategory = async (category) => { // const 앞에 바로 export를 사용해 내보낼 수 있음
  const url = `/3/movie/${category}?language=ko-KR&page=1`;
  const response = await tmdbClient.get(url);
  const movies = response.data.results;

  return movies;
};

export const getMovie = async (movieId)=>{
  const url = `/3/movie/${movieId}?language=ko-KR&page=1`;
  const response = await tmdbClient.get(url);
  const movie = response.data;

  return movie;
  }
